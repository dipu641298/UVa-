/*Writer : Md. Shafiur Rahman Dipu  */

#include <bits/stdc++.h>
using namespace std;

#define FASTER ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);

#define pi 2*acos(0.00)
#define INF 2e18

long long poW(long long base, long long power) {
    long long result = 1;
    while(power > 0) {

        if(power & 1) {
            result = (result*base) ;
        }
        base = (base * base);
        power = power / 2;
    }
    return result;
}

#define ull unsigned long long
#define ll long long
#define ld long double

const int mod = 1000000007;
const int mx = 100005;





int main()
{
    #ifdef dipu
    //freopen("inp.txt","r",stdin);
    #endif


    return 0;
}
