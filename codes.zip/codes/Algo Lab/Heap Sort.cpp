#include<bits/stdc++.h>
using namespace std;

int heapsize;

void Max_heapify(int v[],int n,int i)
{
    int largest = i;
    int l = 2*i+1;
    int r = 2*i+2;

    if(l<n and v[l]>v[largest]){
        largest = l;
    }
    if(r<n and v[r]>v[largest]){
        largest = r;
    }

    if(largest != i){
        swap(v[i],v[largest]);
        Max_heapify(v,n,largest);
    }
}

void heapSort(int v[],int n)
{
    for(int i=n/2-1; i>=0; i--){
        Max_heapify(v,n,i);
    }
    for(int i=n-1; i>=0; i--){
        swap(v[0],v[i]);

        Max_heapify(v,i,0);
    }
}

int main()
{
    //freopen("inp.txt","r",stdin);
    int n;
    cin>>n;
    int v[n];
    for(int i=0; i<n; i++){
        cin>>v[i];
    }

    heapSort(v,n);

    for(int i=0; i<n; i++){
        cout<<v[i]<<" ";
    }
    cout<<endl;
    return 0;
}
