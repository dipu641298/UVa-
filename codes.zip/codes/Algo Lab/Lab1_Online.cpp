/*  Writer : Md. Shafiur Rahman Dipu  */
/*  ID : 16-01-04-098   */
/*  Section : B2   */


#include <bits/stdc++.h>
using namespace std;


int main()
{
    //freopen("inp.txt","r",stdin);
    int n,k;
    cin>>n>>k;
    vector<int> v;
    int x;
    for(int i=0; i<n; i++){
        cin>>x;
        v.push_back(x);
    }
    int cnt = 0;
    for(int i=0; i<n; i++){
        int p = k;
        while(1){
            if(p==v[i]){
                cnt++;
                break;
            }
            p*=k;
            if(p>v[i]){
                break;
            }
        }
    }

    cout<<cnt<<endl;

    return 0;
}


