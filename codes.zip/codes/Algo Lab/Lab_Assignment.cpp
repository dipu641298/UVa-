#include<bits/stdc++.h>
using namespace std;


struct cell{
    int x,y;
};

int countt = 0;
bool visit[100][100];
char ar[100][100];

void twoDbfs(int x,int y,int n,int m)
{
    cell s;
    s.x = x;
    s.y = y;

    int dx[] = {-1,0,1,0};
    int dy[] = {0,-1,0,1};

    queue<cell> q;
    q.push(s);
    visit[s.x][s.y] = true;
    countt++;
    while(!q.empty()){
        cell v = q.front();
        q.pop();
        for(int i=0; i<4; i++){
            cell u;
            u.x = v.x+dx[i];
            u.y = v.y+dy[i];
            if((u.x>=0 && u.y>=0 && u.x<n && u.y<m)and(ar[u.x][u.y] == '.')and(!visit[u.x][u.y])){
                visit[u.x][u.y] = true;
                countt++;
                q.push(u);
            }
        }

    }
}


int main()
{
    int t;
    cin>>t;
    while(t--){
        countt = 0;
        int n,m;
        cin>>n>>m;

        for(int i=0; i<n; i++){
            for(int j=0; j<m; j++){
                cin>>ar[i][j];
            }
        }

        int a,b,c;
        cin>>c;
        memset(visit,false,sizeof(visit));

        cell input[c];

        for(int i=0; i<c; i++){
            cin>>a>>b;

            input[i].x = --a;
            input[i].y = --b;

        }

        for(int i=0; i<c; i++){

            a = input[i].x;
            b = input[i].y;

            if(ar[a][b]=='*'){
                break;
            }
            else if(ar[a][b]=='.'){
                twoDbfs(a,b,n,m);
            }
            else{
                countt++;
            }

        }

        cout<<countt<<endl;

    }


    return 0;
}
