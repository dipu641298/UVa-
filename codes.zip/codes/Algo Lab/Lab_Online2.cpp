// Writer : Md. Shafiur Rahman Dipu
// ID : 16.01.04.098
// Section : B2


#include<bits/stdc++.h>
using namespace std;

int partition(int ar[], int low,int high)
{
    int pivot = ar[high];
    int i = low-1;

    for(int j=low; j<high; j++){
        if(ar[j]%3>pivot%3){
            i++;
            swap(ar[i],ar[j]);
        }
        else if(ar[j]%3==pivot%3){
            if(ar[j]<pivot){
                swap(ar[j],ar[high]);
            }
        }
    }
    swap(ar[i+1],ar[high]);

    return i+1;
}


void qsort(int ar[],int low,int high)
{
    if(low<high){
        int pi = partition(ar,low,high);

        qsort(ar,low,pi-1);
        qsort(ar,pi+1,high);
    }
}



int main()
{
    int n;
    cin>>n;

    int ar[n];
    for(int i=0; i<n; i++){
        cin>>ar[i];
    }
    qsort(ar,0,n-1);
    for(int i=0; i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;

    return 0;
}

