#include<bits/stdc++.h>
using namespace std;


void hpf(int ar[],int n,int i)
{
    int la = i;
    int l = 2*i;
    int r = 2*i+1;

    if(l<n and ar[l]>ar[la]){
        la = l;
    }
    if(r<n and ar[r]>ar[la]){
        la =r;
    }

    if(la!=i){
        swap(ar[i],ar[la]);
        hpf(ar,n,la);
    }
}

void hs(int ar[],int n)
{
    for(int i=n/2-1; i>=0; i--){
        hpf(ar,n,i);
    }

    for(int i=n-1; i>=0; i--){
        swap(ar[0],ar[i]);
        hpf(ar,i,0);
    }
}

int main()
{
    int n;
    cin>>n;
    int ar[n];
    int ar1[n];
    int ar2[n];
    int a=0;
    int b=0;
    for(int i=0; i<n; i++){
        cin>>ar[i];
        if(ar[i]%2==0){
            ar1[a] = ar[i];
            a++;
        }
        else{
            ar2[b] = ar[i];
            b++;
        }
    }

    hs(ar1,a);
    hs(ar2,b);

    for(int i=0; i<b; i++){
        cout<<ar2[i]<<" ";
    }

    for(int i=0; i<a; i++){
        cout<<ar1[i]<<" ";
    }


    return 0;

}
