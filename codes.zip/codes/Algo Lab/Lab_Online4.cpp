/*  Written by : Md. Shafiur Rahman Dipu
            ID : 16-01-04-098
       Section : B2
       */

#include<bits/stdc++.h>
using namespace std;

int col[100];
stack<int> st;
vector<int> scc;
bool rev = false;

void dfs(vector<int> v[], int s)
{
    if(rev){
        scc.push_back(s);
    }
    col[s] = 1;
    for(int i=0; i<v[s].size(); i++){
        int x = v[s][i];
        if(col[x]==0){
            dfs(v,x);
        }
    }
    col[s] = 2;
    if(!rev){
        st.push(s);
    }
}

int main()
{
    int v,e;
    cin>>v>>e;

    vector<int> v1[100];
    vector<int> v2[100];

    for(int i=0; i<e; i++){
        int a,b;
        cin>>a>>b;
        v1[a].push_back(b);
        v2[b].push_back(a);
    }

    memset(col,0,sizeof(col));
    for(int i =1; i<=v; i++){
        if(col[i]==0){
            dfs(v1,i);
        }
    }
    memset(col,0,sizeof(col));
    rev = true;
    int cnt = 0;
    bool fnd = false;
    while(!st.empty()){
        int x = st.top();
        if(col[x]==0){
            dfs(v2,x);
            if(scc.size()>1){
                cout<<"YES"<<endl;
                fnd = true;
                break;
            }
            scc.clear();
        }

        st.pop();
    }
    if(!fnd){
        cout<<"NO"<<endl;
    }
    return 0;
}
