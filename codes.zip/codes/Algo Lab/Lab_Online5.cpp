#include<bits/stdc++.h>
using namespace std;

struct ss{
    double weight;
    double price;
    double ratioo;
};

bool comp(ss a,ss b)
{
    return a.ratioo > b.ratioo;
}

int main()
{
    int n;
    double w;
    cin>>n>>w;
    ss ar[n];
    for(int i=0; i<n; i++){
        cin>>ar[i].weight>>ar[i].price;
        ar[i].ratioo = ar[i].price/ar[i].weight;
    }
    sort(ar,ar+n,comp);
    double res = 0.00;
    for(int i=0; i<n; i++){
        if(w-ar[i].weight >= 0){
            w -= ar[i].weight;
            res += ar[i].price;
        }
        else{
            res += (w/ar[i].weight) * ar[i].price;
            break;
        }
    }

    cout<<res<<endl;

    return 0;
}
