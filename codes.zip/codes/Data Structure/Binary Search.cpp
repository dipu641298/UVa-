#include<bits/stdc++.h>
using namespace std;

int bSearch(int ar[],int v,int l,int h)
{
    if(h>=l){
        int mid = (l+h)/2;
        if(ar[mid]==v){
            return mid;
        }
        else if(ar[mid]>v){
            return bSearch(ar,v,l,mid-1);
        }
        return bSearch(ar,v,mid+1,h);
    }
    return -1;
}

int main()
{
    int n,v,index,x;
    cout<<"Enter the array size : ";
    cin>>n;
    int ar[n];
    for(int i=0; i<n; i++){
        cin>>x;
        ar[i]=x;
    }
    sort(ar,ar+n);
    cout<<"The array is : ";
    for(int i=0; i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;
    cout<<"Enter the value to search : ";
    cin>>v;
    index = bSearch(ar,v,0,n-1);
    (index != -1) ? cout<<"The value is at index "<<index<<endl
                  : cout<<"This value is not in the array"<<endl;
    return 0;
}
