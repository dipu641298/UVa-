#include<bits/stdc++.h>
using namespace std;

bool visit [100000];

void DFS(vector<int> conn[],int node)
{
    visit[node] = true;
    cout<<node<<" ";

    for(int i=0; i<conn[node].size(); i++){
        int x = conn[node][i];
        if(!visit[x]){
            DFS(conn,x);
        }
    }

}

int main()
{
    int node,edge;
    int a,b,p;
    cin>>node>>edge;
    vector<int> conn[1000];
    for(int i=0; i<edge; i++){
        cin>>a>>b;
        conn[a].push_back(b);
        conn[b].push_back(a);
    }
    memset(visit,false,sizeof(visit));
    for(int i=1; i<=node; i++){
        if(!visit[i]){
            DFS(conn,i);
        }
    }

    return 0;
}

