#include<bits/stdc++.h>
using namespace std;

int ar[3][100],empty[100]={0};
int in = 1,out = 1,n,empIndeex=1;
bool check[100] = {false};


void create(int n)
{
    for(int i=1; i<=n; i++){
        ar[1][i]=0;
        ar[2][i]=-1;
    }
}

void insert(int a)
{
    ar[1][in] = a;
    ar[2][in] = in+1;
    in++;
}

void Delete(int a)
{
    for(int i=1; i<=n; i++){
        if(ar[1][i]==a){
            ar[1][i] = 0;
            ar[2][i] = -1;
        }
    }
}

int main()
{
    cout<<"Enter number of index : ";
    cin>>n;

    create(n);
    insert(10);
    insert(20);
    insert(30);
    insert(40);
    insert(50);

    cout<<"\nData : ";
    while(ar[1][out]!=0){
        cout<<ar[1][out]<<" ";
        out++;
    }
    cout<<"\nEmpty indexes : ";
    for(int i = in; i<=n; i++){
        cout<<i<<" ";
        empty[empIndeex] = i;
        check[i] = true;
        empIndeex++;
    }

    Delete(20);
    Delete(30);

    cout<<"\nData after delete : ";
    for(int i =1; i<=n; i++){
        if(ar[1][i]!=0){
            cout<<ar[1][i]<<" ";
        }
    }

    //cout<<"\nEmpty indexes after delete : ";
    for(int i =1; i<=n; i++){
        if(ar[1][i]==0){
            //cout<<i<<" ";
            if(check[i] == false){
               empty[empIndeex] = i;
               check[i] = true;
               empIndeex++;
            }
        }
    }

    cout<<"\nEmpty indexes after delete : ";
    for(int i =1; i<empIndeex; i++){
        cout<<empty[i]<<" ";
    }
    cout<<endl;
    return 0;
}
