#include<bits/stdc++.h>
using namespace std;

void insertion(int ar[],int n)
{
    int t,i;
    for(int j=2; j<=n; j++){
        i= j-1;
        t = ar[j];
        while(t < ar[i]){
            ar[i+1] = ar[i];
            i-=1;
        }
        ar[i+1] = t;
    }
}
int main()
{
    int n;
    cout<<"Enter the array size : ";
    cin>>n;
    int ar[n+1];
    ar[0]= -9999990;
    for(int i=1; i<=n; i++){
        ar[i]=rand()%10;
    }
    cout<<"The array is : ";
    for(int i=1; i<=n; i++){
        cout<<ar[i]<<" ";
    }
    insertion(ar,n);
    cout<<endl;
    cout<<"The sorted array is : ";
    for(int i=1; i<=n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;
    return 0;
}
