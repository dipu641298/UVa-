#include<bits/stdc++.h>
using namespace std;

struct node{
    int data;
    node* prev;
    node* next;
};

node* head;
node* head2;

void Insert(int x,int p)
{
    node* temp = new node;
    temp->prev = NULL;
    temp->next = NULL;
    temp->data = x;
    if(p==1 && head==NULL){
        head = temp;
        head2 = temp;
        return;
    }
    else if(p==1 && head!=NULL){
        head->prev = temp;
        temp->next = head;
        head = temp;

        return;
    }
    else{
        node* temp1 = new node;
        node* temp2 = new node;
        temp1 = head;
        for(int i=0; i<p-2; i++){
           temp1 = temp1->next;
        }
        temp->next = temp1->next;
        temp->prev = temp1;
        temp1->next = temp;
        if(temp->next!=NULL){
            temp2 = temp->next;
            temp2->prev = temp;
        }
        else if(temp->next==NULL){
            head2 = temp;
        }
    }
}


void Delete(int d)
{
    node* temp1 = new node;
    node* temp2 = new node;
    node* unode = new node;
    temp1 = head;
    if(d==1){
        head = temp1->next;
        delete temp1;
        return;
    }
    for(int i=0; i<d-1; i++){
        temp1 = temp1->next;
    }
    temp2 = temp1->next;
    if(temp2!=NULL){
        head2 = temp2;
        temp2->prev = temp1->prev;
        unode = temp1->prev;
        unode->next = temp2;
    }
    if(temp2==NULL){
        head2 = temp1->prev;
        unode = temp1->prev;
        unode->next = NULL;
    }
    delete temp1;

}
void Print()
{
    node* temp  = new node();
    node* temp1 = new node();
    temp = head;
    while(temp!= NULL){
        cout<<temp->data<<" ";
        temp = temp->next;
    }
    cout<<endl;
    temp1 = head2;
    while(temp1!=NULL){
        cout<<temp1->data<<" ";
        temp1 = temp1->prev;
    }
    cout<<endl;
}

int main()
{
    head = NULL;
    int op,c=0,p,d,x;
    cout<<"Enter your option : \n1.Insert\t\t\t2.Delete\t\t\t3.Print\t\t\t4.exit"<<endl;
    for(int i=1;;i++){
        cin>>op;
        if(op==1){
            c++;
            cout<<"Enter the number and position : ";
            cin>>x>>p;
            if(p<1 || p>c){
                cout<<"Invalid position"<<endl;
            }
            else{
                Insert(x,p);
            }
        }
        else if(op==2){
            cout<<"Enter the position to delete : ";
            cin>>d;
            if(d<0 || d>c){
                cout<<"Invalid position"<<endl;
            }
            else{
                Delete(d);
                c--;
            }
        }
        else if(op==3){
            Print();
        }
        else{
            break;
        }
        cout<<endl<<"Enter your option : \n1.Insert\t\t\t2.Delete\t\t\t3.Print\t\t\t4.exit"<<endl;
    }
    return 0;

}
