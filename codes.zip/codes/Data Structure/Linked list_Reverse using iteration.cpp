#include<bits/stdc++.h>
using namespace std;

struct node{
    int data;
    node* link;
};

node* head;

void Insert(int x)
{
    node* temp1 = new node();
    temp1->data = x;
    temp1->link = NULL;
    if(head == NULL){
        head = temp1;
        return;
    }
    node* temp2 = head;
    while(1){
        if(temp2->link==NULL){
            break;
        }
        temp2 = temp2->link;
    }
    temp2->link = temp1;
}

void Print()
{
    node* temp = head;
    while (temp!=NULL){
        cout<<temp->data<<" ";
        temp = temp->link;
    }
    cout<<endl;
}

void Reverse()
{
    node *current,*prev,*next;
    current = head;
    prev = NULL;
    while(current!=NULL){
        next = current->link;
        current->link = prev;
        prev = current;
        current = next;
    }
    head = prev;
}

int main()
{
    head  = NULL;
    int x,n;
    cout<<"How many numbers to input : ";
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>x;
        Insert(x);
        //Print();
    }
    Reverse();
    Print();
    return 0;
}
