#include<bits/stdc++.h>
using namespace std;

struct node{
    int data;
    node* link;
};

node* head;

void Insert(int element)
{
    node* temp1 = new node();
    temp1->data = element;
    temp1->link = NULL;
    if(head == NULL){
        head = temp1;
        temp1->link = NULL;
        return;
    }
    node* temp2 = new node();
    temp2 = head;
    while(1){
        if(temp2->link==NULL){
            break;
        }
        temp2 = temp2->link;
    }
    temp2->link = temp1;
}

void Print()
{
    node* temp  = new node();
    temp = head;
    while(temp != NULL){
        cout<<temp->data<<" ";
        temp = temp->link;
    }
    cout<<endl;
}

void Delete(int p){
    node* temp1 = new node();
    node* temp2 = new node();
    temp1 = head;
    if(p==1){
        head = temp1->link;
        delete temp1;
        return;
    }
    for(int i=0; i<p-2; i++){
        temp1 = temp1->link;
    }
    temp2 = temp1->link;
    temp1->link = temp2->link;
    delete temp2;
}

int main()
{
    head = NULL;
    int element,n,p;
    cout<<"How many elements : ";
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>element;
        Insert(element);
        cout<<"Now the list is : ";
        Print();
    }
    Print();
    cout<<endl;
    while(1){
        cout<<"Enter the position to delete.Enter -1 to stop deleting : ";
        cin>>p;
        if(p<0){
            break;
        }
        Delete(p);
        cout<<"Now the list is : ";
        Print();
    }
    return 0;
}
