#include<bits/stdc++.h>
using namespace std;

struct node{
    int data;
    node* link;
};

node* head;

void Insert(int x, int p)
{
    node* temp1 = new node();
    temp1->data = x;
    temp1->link = NULL;
    if(p==1){
        temp1->link = head;
        head = temp1;
        return ;
    }
    node* temp2 = head;
    for(int i=0; i<p-2; i++){
        temp2 = temp2->link;
    }
    temp1->link = temp2->link;
    temp2->link = temp1;
}

void print()
{
    node* temp = head;
    cout<<"The list is : ";
    while(temp != NULL){
        cout<<temp->data<<" ";
        temp = temp->link;
    }
    cout<<endl;
}

int main()
{
    head = NULL;
    int x,p,c=0;
    for(int i=0; ; i++){
        c++;
        cout<<"Enter the number and position : ";
        cin>>x>>p;
        if(p==-1){
            break;
        }
        if(p<1 || p>c){
            cout<<"Invalid position"<<endl;
        }
        else{
            Insert(x,p);
            print();
        }
    }
    return 0;
}
