#include<bits/stdc++.h>
using namespace std;

struct node{
    int data;
    node* link;
};

node* head;
int p=0;

void Insert(int x)
{
    node* temp1 = new node();
    temp1->data = x;
    temp1->link = NULL;
    if(p==0){
        head = temp1;
        temp1->link = head;
        p++;
        return ;
    }
    node* temp2 = head;
    for(int i=0; i<p-1; i++){
        temp2 = temp2->link;
    }
    temp2->link = temp1;
    temp1->link = head;
    p++;
}

void print(int x){
    node* temp = head;
    cout<<"List is : ";
    while(1){
        if(temp->data == x){
            cout<<temp->data<<" ";
            for(int i=0; i<p-1; i++){
                temp = temp->link;
                cout<<temp->data<<" ";
            }
            break;
        }
        else{
            temp = temp->link;
        }
    }
    cout<<endl;
}
int main()
{
    cout<<"How many numbers to input : ";
    int n,x;
    cin>>n;
    for(int i=0; i<n; i++){
        cin>>x;
        Insert(x);
    }
    cout<<"Enter a node : ";
    cin>>x;
    print(x);
    return 0;
}
