#include<bits/stdc++.h>
using namespace std;

#define inf 9999999

int Merge(int ar[], int p, int q,int h)
{
    int n1 = q-p+1;
    int n2 = h-q;
    int l[n1+2];
    int r[n2+2];
    for(int i=0; i<=n1; i++){
        l[i] = ar[p+i-1];
    }
    for(int i=0; i<=n2; i++){
        r[i] = ar[q+i];
    }
    l[n1+1] = inf;
    r[n2+1] = inf;
    int i = 1,j = 1;
    for(int k=p; k<=h; k++){
        if(l[i]<=r[j]){
            ar[k] = l[i];
            i++;
        }
        else{
            ar[k] = r[j];
            j++;
        }
    }
}

int mSort(int ar[],int p, int r)
{
    int q;
    if(p<r){
        q = (p+r)/2;
        mSort(ar,p,q);
        mSort(ar,q+1,r);
        Merge(ar,p,q,r);
    }
}

int main()
{
    //freopen("inp.txt","r",stdin);
    int n;
    cout<<"Enter the size of array : ";
    cin>>n;
    int ar[n+1];
    for(int i=1; i<=n; i++){
        cin>>ar[i];
    }
    cout<<endl<<"The array before sort : ";
    for(int i=1; i<=n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;
    mSort(ar,1,n);
    cout<<"\nThe array after sort : ";
    for(int i=1; i<=n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl<<endl;
    return 0;
}
