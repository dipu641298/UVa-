#include<bits/stdc++.h>
using namespace std;

template<typename T>
struct queu{
    int qu[10];
    int l = -1;
    int n;

    void push(){
        if(l<4){
            l++;
            cout<<"enter value to push : ";
            cin>>n;
            qu[l] = n;
            cout<<"pushed "<<n<<endl;
        }
        else if(l>=4){
            cout<<"Stackoverflown"<<endl;
        }
    }

    void pop(){
        if(l == -1){
            cout<<"Can't pop. Empty list"<<endl;
        }
        else{
            cout<<"popped "<<qu[0]<<endl;
            for(int i=1; i<=l; i++){
                qu[i-1]=qu[i];
            }
            l--;
        }
    }

    void display()
    {
        if(l==-1){
            cout<<"Nothing to display.Empty list"<<endl;
        }
        else{
            for(int i=0; i<=l; i++){
                cout<<qu[i]<<" ";
            }
            cout<<endl;
        }
    }
};

int main()
{
    queu<int> q;
    int op;
    cout<<"1.push\t\t2.pop\t\t3.display\t\t4.exit"<<endl;
    cout<<"enter your option : ";
    while(cin>>op && op!=4){
        if(op==1){
           q.push();
        }
        else if(op==2){
            q.pop();
        }
        else if(op==3){
            q.display();
        }
        cout<<"\n1.push\t\t2.pop\t\t3.display\t\t4.exit"<<endl;
        cout<<"Again enter your option : ";
    }
    return 0;
}
