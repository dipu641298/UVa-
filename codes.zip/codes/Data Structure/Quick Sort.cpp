#include<bits/stdc++.h>
using namespace std;

int partition(int ar[], int low,int high)
{
    int pivot = ar[high];
    int i = low-1;

    for(int j=low; j<high; j++){
        if(ar[j]<=pivot){
            i++;
            swap(ar[i],ar[j]);
        }
    }
    swap(ar[i+1],ar[high]);

    return i+1;
}


void qsort(int ar[],int low,int high)
{
    if(low<high){
        int pi = partition(ar,low,high);

        qsort(ar,low,pi-1);
        qsort(ar,pi+1,high);
    }
}



int main()
{
    freopen("inp.txt","r",stdin);
    int n;
    cout<<"Enter the size of array : ";
    cin>>n;

    int ar[n];
    for(int i=0; i<n; i++){
        cin>>ar[i];
    }

    cout<<endl<<"The array before sort : ";
    for(int i=0 ;i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;

    cout<<endl<<"The array after sort : ";
    qsort(ar,0,n-1);

    for(int i=0; i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;

    return 0;
}
