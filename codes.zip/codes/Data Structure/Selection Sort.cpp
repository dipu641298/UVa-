#include<bits/stdc++.h>
using namespace std;

int sSort(int ar[],int n){
    int t;
    for(int j=n-1; j>=1; j--){
        t=0;
        for(int k=1; k<=j; k++){
            if(ar[t]<ar[k]){
                t=k;
            }
        }
        swap(ar[j],ar[t]);
    }
}

int main()
{
    int n;
    cout<<"Enter the size of array : ";
    cin>>n;
    int ar[n];
    for(int i=0; i<n; i++){
        ar[i] = rand()%10;
    }
    cout<<"The array before sort : ";
    for(int i=0; i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl;
    sSort(ar,n);
    cout<<"\nThe array after sort : ";
    for(int i=0; i<n; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl<<endl;
    return 0;
}
