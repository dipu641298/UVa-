#include<bits/stdc++.h>
using namespace std;

#define m 5

template<typename T>
struct Stack{
    int s[m];
    int l=m-1;
    int n;

    void push()
    {
        if(l>=0){
            cout<<"enter value to push : ";
            cin>>n;
            s[l] = n;
            l--;
            cout<<"pushed "<<n<<endl;
        }
        else if(l<0){
            cout<<"Stackoverflown"<<endl;
        }
    }

    void pop()
    {
        if(l == m-1 ){
            cout<<"Can't pop. Empty list"<<endl;
        }
        else{
            cout<<"popped "<<s[l+1]<<endl;
            l++;
        }
    }

    void display()
    {
        if(l==m-1){
            cout<<"Nothing to display.Empty list"<<endl;
        }
        else{
            for(int i=l+1; i<=m-1; i++){
                cout<<s[i]<<" ";
            }
            cout<<endl;
        }
    }
};

int main()
{
    Stack<int> ss;
    int op;
    cout<<"1.push\t\t2.pop\t\t3.display\t\t4.exit"<<endl;
    cout<<"enter your option : ";
    while(cin>>op && op!=4){
        if(op==1){
           ss.push();
        }
        else if(op==2){
            ss.pop();
        }
        else if(op==3){
            ss.display();
        }
        cout<<"\n1.push\t\t2.pop\t\t3.display\t\t4.exit"<<endl;
        cout<<"Again enter your option : ";
    }
    return 0;
}
