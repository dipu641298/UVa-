#include<bits/stdc++.h>
using namespace std;

struct S{
    int disk,i,j,k;
}s,p;

int main()
{
    int disk;
    stack<struct S> g;
    cout<<"Enter the number of disk : ";
    cin>>disk;
    s.disk = disk;
    s.i = 1;
    s.j = 2;
    s.k = 3;
    g.push(s);
    while(g.size() !=0){
        s = g.top();
        if(s.disk == 1){
            cout<<"Move top disk from pole "<<s.i<<" to pole "<<s.k<<endl;
            g.pop();
        }
        else{
            g.pop();

            p.disk = s.disk-1;
            p.i = s.j;
            p.j = s.i;
            p.k = s.k;
            g.push(p);

            p.disk = 1;
            p.i = s.i;
            p.j = s.j;
            p.k = s.k;
            g.push(p);

            p.disk = s.disk-1;
            p.i = s.i;
            p.j = s.k;
            p.k = s.j;
            g.push(p);
        }
    }
    return 0;
}
