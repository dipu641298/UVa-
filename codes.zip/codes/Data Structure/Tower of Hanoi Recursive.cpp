#include<bits/stdc++.h>
using namespace std;

int move(int disk,int i,int k, int j)
{
    if(disk>0){
        move(disk-1,i,j,k);
        cout<<"Move disk "<<disk<<" from bar "<<i<<" to bar "<<k<<endl;
        move(disk-1,j,k,i);
    }
}

int main()
{
    int disk,i=1,j=2,k=3;
    cout<<"Enter the number of disk : ";
    cin>>disk;
    move(disk,i,k,j);
    return 0;
}
