#include <stdio.h>
#include <stdlib.h>

struct stack
{
    int disk;
    int a,b,c;
};
 struct stack ar[1000];
 int t=-1;
 int size = 0;
 int n;

 void push(int disk,char x,char y,char z)
 {
     t++;
     size++;
     ar[t].disk = disk;
     ar[t].a = x;
     ar[t].b = y;
     ar[t].c = z;
 }

 struct stack pop()
 {
     size--;
     return ar[t--];
 }

 int main()
 {
     printf("Enter the number of disk: ");
     scanf("%d",&n);
     char i='A',j='B',k='C';

     push(n,i,j,k);
     while(size != 0)
     {
         struct stack m= pop();
         n = m.disk;
         i = m.a;
         j = m.b;
         k = m.c;

         if(n == 1)
         {
             printf("\nMove disk from pole %c to %c",i,k);
         }
         else
         {
             push(n-1,j,i,k);
             push(1,i,j,k);
             push(n-1,i,k,j);
         }

     }

     return 0;
 }
