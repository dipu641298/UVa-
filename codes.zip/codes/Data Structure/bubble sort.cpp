#include<bits/stdc++.h>
#include<ctime>
using namespace std;

long long int c1=0,c2=0;

void bsort(int ar[],int size)
{
    int temp,k=size,t;
    while(k!=0){
        t=0;
        for(int j=0; j<k; j++){
            c1++;
            if(ar[j]>ar[j+1]){
                c2++;
                temp=ar[j];
                ar[j]=ar[j+1];
                ar[j+1]=temp;
                t=j;
            }
        }
        k=t;
    }
}

int main()
{
    int size=5,ar[size];
    clock_t time1,time2;
    for(int i=0; i<size; i++){
        ar[i]=rand()%20000;
    }
    int t1= time_t ();
    time1 = clock();
    bsort(ar,size);
    time2 = clock();
    int t2= time_t();
    for(int i=0; i<size; i++){
        cout<<ar[i]<<" ";
    }
    cout<<endl<<endl;
    cout<<"Number of comparison : "<<c1<<endl;
    cout<<"Number of data movement : "<<3*c2<<endl;
    cout<<"Time for bubble sort : "<<time2-time1<<endl;
    return 0;
}

