#include<bits/stdc++.h>
using namespace std;
int mark[38573];
int main()
{
    string a;
    string b;
    cin>>a>>b;
    int l1=a.size();
    int l2=b.size();
    for (int i=0;i<l1;i++)
    {
        int x;
        x=a[i]-'0';
        mark[x]=1;

    }
       for (int i=0;i<l2;i++)
    {
        int x;
        x=b[i]-'0';
        if(mark[x]!=1)
            cout<<b[i];

    }
    cout<<endl;
}
