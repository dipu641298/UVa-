#include<bits/stdc++.h>
using namespace std;

int main()
{
    int ar[100],pos=0,s;
    bool posc=false;
    for(int i=0; i<100; i++){
        ar[i]=rand()%100;
    }
    cout<<"Enter the input to be searched : ";
    cin>>s;
    for(int i=0; i<100; i++){
        for(int j=i; j<100; j++){
            if(ar[j]==s){
               pos=j;
               posc=true;
               break;
            }
        }
        if(posc==true){
            break;
        }
    }
    if(posc==false){
        cout<<"The input couldn't be found"<<endl;
        return 0;
    }
    cout<<"The position of the input is : "<<pos<<endl;
    return 0;
}
