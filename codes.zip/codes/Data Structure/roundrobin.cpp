#include<bits/stdc++.h>
using namespace std;
struct data
{
    int pid;
    int arriv;
    int burst;
    int nextarrival;


}ar[394];
int mark[10];
int waiting[48];
bool comp(struct data f1,struct data f2)
{
    return f1.arriv<f2.arriv;
}
int main()
{
    cout<<"Enter the number of pids"<<endl;
    int n;
    cin>>n;
    cout<<"Enter time quantum"<<endl;
    int tq;
    cin>>tq;
    for (int i=0;i<n;i++)
    {
        int x,y,z;
        cin>>x>>y>>z;
        ar[i].pid=x;
        ar[i].arriv=y;
        ar[i].burst=z;


    }

    sort(ar,ar+n,comp);

    for (int i=0;i<n-1;i++)
    {
        ar[i].nextarrival=ar[i+1].arriv;

    }
    deque<int> deq;
    map<int,int> mp;
    map<int,int> mp2;
    map<int,int> mp3;
    for (int i=0;i<n;i++)
    {
        deq.push_back(ar[i].pid);
        mp[ar[i].pid]=ar[i].burst;
        mp2[ar[i].pid]=ar[i].arriv;
        mp3[ar[i].pid]=ar[i].nextarrival;
    }
    //cout<<"def ront "<<deq.front()<<endl;

    int totaltime=0;

    memset(waiting,0,sizeof(waiting));

    while(!deq.empty())
    {
        int top=deq.front();
        cout<<"top "<<top<<endl;
        cout<<"mp2[top "<<mp2[top]<<endl;
        int rem=mp[top];
        if(rem>tq)
        {
            cout<<"pre total "<<totaltime<<endl;
            if(mp2[top]!=0)
            waiting[top]+=totaltime-mp2[top];
            totaltime+=tq;
            cout<<"totaltime "<<totaltime<<endl;
             cout<<"prev waiting "<<waiting[top]<<endl;
             if(mp2[top]!=0)

             {

                mp2[top]=totaltime;
             }
             cout<<"post waiting "<<waiting[top]<<endl;
            rem-=tq;
            mp[top]=rem;
            if(mp3[top]>totaltime)
                continue;
            deq.pop_front();
            deq.push_back(top);

        }
        else if(rem==tq)
        {
            totaltime+=tq;
          //  cout<<"prev waiting "<<waiting[top]<<endl;

            waiting[top]+=totaltime-mp2[top];
             //cout<<"post waiting "<<waiting[top]<<endl;

            if(mp3[top]>totaltime)
                totaltime+=(mp3[top]-totaltime);
            deq.pop_front();


        }
      /*  else if(rem==0)
        {
            deq.pop_front();
        }*/
        else if(rem<tq)
        {
            totaltime+=rem;
             waiting[top]+=totaltime-mp2[top];
              if(mp3[top]>totaltime)
                totaltime+=(mp3[top]-totaltime);
             deq.pop_front();


        }

          cout<<"waiti "<<waiting[top]<<endl<<endl;

    }
    cout<<"Total time "<<totaltime<<endl;

    cout<<"owned waiting time "<<endl;
    for (int i=0;i<n;i++)
    {
        cout<<"P "<<ar[i].pid<<" "<<waiting[i]<<endl;
    }


}
/*
4
1 4 5
2 0 7
3 6 9
4 10 9
*/
