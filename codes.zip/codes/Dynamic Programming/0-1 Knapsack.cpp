#include<bits/stdc++.h>
using namespace std;

struct ss{
    int wt;
    int p;
};

int max(int a,int b)
{
    return (a>b)?a:b;
}

int br[1000][1000];

int knapsack(ss ar[],int w,int n)
{
    memset(br,0,sizeof(br));
    int k[n+1][w+1];
    for(int i=0; i<=n; i++){
        for(int j=0; j<=w; j++){
            if(i==0 || j==0){
                k[i][j]=0;
            }
            else if(ar[i-1].wt<=j){
                k[i][j] = max(ar[i-1].p+k[i-1][j-ar[i-1].wt],k[i-1][j]);
            }
            else{
                k[i][j] = k[i-1][j];
                br[i][j] = 1;
            }
        }
    }
    return k[n][w];
}

int main()
{
    int n,w;
    cin>>n>>w;
    ss ar[n];
    for(int i=0; i<n; i++){
        cin>>ar[i].wt>>ar[i].p;
    }

    int res = knapsack(ar,w,n);
    cout<<res<<endl<<endl;

    return 0;
}

