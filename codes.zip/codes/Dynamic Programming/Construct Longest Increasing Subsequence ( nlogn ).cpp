#include<bits/stdc++.h>
using namespace std;


int getCeil(vector<int>&t, int l, int r, int key)
{
    while(r-l>1){
        int m = l+(r-l)/2;
        if(t[m]>=key){
            r= m;
        }
        else{
            l = m;
        }
    }
    return r;
}

int LIS(vector<int>&v)
{
    int n= v.size();
    vector<int> t(n,0);
    vector<int> p(n,-1);
    int len =1;
    for(int i=1; i<n; i++){
        if(v[i]<v[t[0]]){
            t[0]=i;
        }
        else if(v[i]>v[t[len-1]]){
            p[i] = t[len-1];
            t[len++] = i;
        }
        else{
            int pos = getCeil(t,-1,len-1,v[i]);
            p[i] = t[pos-1];
            t[pos] = i;
        }
    }
    for(int i=t[len-1]; i>=0; i=p[i]){
        cout<<v[i]<<" ";
    }
    cout<<endl;
    return len;
}

int main()
{
    vector<int> v;
    int x;
    for(int i=0; i<9; i++){
        cin>>x;
        v.push_back(x);
    }
    int l = LIS(v);
    cout<<l<<endl;
    return 0;
}
