#include<bits/stdc++.h>
using namespace std;

int max(int a, int b)
{
    return (a>b)?a:b;
}

int LCS(string a,string b,int m,int n)
{
    int l[m+1][n+1];
    vector<char>lcs;
    for(int i=0; i<=m; i++){
        for(int j=0; j<=n; j++){
            if(i==0 || j==0){
                l[i][j]=0;
            }
            else if(a[i-1]==b[j-1]){
                l[i][j] = 1+ l[i-1][j-1];
            }
            else{
               l[i][j] = max(l[i][j-1],l[i-1][j]);
            }
        }
    }
    int i=m, j=n;
    while(i>0 && j>0){
        if(a[i-1]==b[j-1]){
            lcs.push_back(a[i-1]);
            i--;
            j--;
        }
        else if(l[i-1][j]>l[i][j-1]){
            i--;
        }
        else{
            j--;
        }
    }
    for(int p=lcs.size()-1; p>=0; p--){
        cout<<lcs[p];
    }
    cout<<endl;
    return l[m][n];
}

int main()
{
    string a,b;
    getline(cin,a);
    getline(cin,b);
    int m = a.length();
    int n = b.length();
    int res = LCS(a,b,m,n);
    cout<<res<<endl;
    return 0;
}
