#include<bits/stdc++.h>
using namespace std;

int getCeil(vector<int>t, int l,int r, int key)
{
    while(r-l>1){
        int m = l+(r-l)/2;
        if(t[m]>=key){
            r = m;
        }
        else{
            l = m;
        }
    }
    return r;
}

int LIS(vector<int> v)
{
    if(v.size() == 0){
        return 0;
    }
    int n = v.size();
    vector<int> t(n,0);
    int len = 1;
    t[0] = v[0];
    for(int i=1; i<n; i++){
        if(v[i]<t[0]){
            t[0]=v[i];
        }
        else if(v[i]>t[len-1]){
            t[len++] = v[i];
        }
        else{
           t[getCeil(t,-1,len-1,v[i])] = v[i];
        }
    }
    return len;
}

int main()
{
    vector<int>v;
    int n;
    cin>>n;
    int x;
    for(int i=0 ; i<n; i++){
        cin>>x;
        v.push_back(x);
    }
    int l = LIS(v);
    cout<<l<<endl;
    return 0;
}
