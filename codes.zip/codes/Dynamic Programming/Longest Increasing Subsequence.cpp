#include<bits/stdc++.h>
using namespace std;


int LIS(int ar[],int n)
{
    int t[n];
    for(int i=0; i<n; i++){
        t[i]=1;
    }
    for(int i=1; i<n; i++){
        for(int j=0; j<i; j++){
            if(ar[j]<ar[i]){
                t[i] = max(t[i],t[j]+1);
            }
        }
    }
    sort(t,t+n);
    return t[n-1];
}

int main()
{
    int ar[8] = {10,22,9,33,21,50,41,60},m;
    m=LIS(ar,8);
    cout<<m<<endl;
    return 0;
}
