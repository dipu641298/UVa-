#include<bits/stdc++.h>
using namespace std;

void bfs(int head, vector<int> conn[],int node)
{
    bool visit [node+1];
    memset(visit,false,sizeof(visit)/sizeof(visit[0]));
    queue<int> level;
    level.push(head);
    visit[head] = true;
    while(!level.empty()){
        int x = level.front();
        level.pop();
        cout<<x<<" ";
        for(int j=0; j<conn[x].size(); j++){
            if(!visit[conn[x][j]]){
                level.push(conn[x][j]);
                visit[conn[x][j]] = true;
            }
        }
    }

}

int main()
{
    int node,edge;
    int a,b,p;
    cin>>node>>edge;
    vector<int> conn[node];
    for(int i=0; i<edge; i++){
        cin>>a>>b;
        conn[a].push_back(b);
        conn[b].push_back(a);
    }
    cout<<"Enter the head note : ";
    cin>>p;
    bfs(p,conn,node);
    return 0;
}
