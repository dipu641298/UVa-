#include<bits/stdc++.h>
using namespace std;


struct node{
    string color;
    int distance;
    string adjacent;
};

void bfs(vector<int>conn[], int head, int nodeNumber)
{
    struct node n[nodeNumber+1];
    for(int i=0; i<=nodeNumber; i++){
        n[i].color = "White";
        n[i].distance = 999999999;
        n[i].adjacent = "";
    }
    n[head].color = "Grey";
    n[head].distance = 0;
    n[head].adjacent = "";

    queue<int> level;
    level.push(head);

    while(!level.empty()){
        int x = level.front();
        level.pop();
        cout<<x<<" ";
        for(int i=0; i<conn[x].size(); i++){
            if(n[conn[x][i]].color=="White"){
                n[conn[x][i]].color = "Grey";
                n[conn[x][i]].distance = n[x].distance+1;
                n[conn[x][i]].adjacent += x;
                level.push(conn[x][i]);
            }
        }
    }
}
int main()
{
    int node,edge,a,b,p;
    cin>>node>>edge;
    vector<int> samp;
    vector<int> conn[100];

    for(int i=0; i<edge; i++){
        cin>>a>>b;
        conn[a].push_back(b);
        conn[b].push_back(a);
    }
    cout<<"Enter the head note : ";
    cin>>p;
    for(int i=1; i<node; i++){
        cout<<i<<"s adjacent is : ";
        for(int j=0; j<conn[i].size(); j++){
            cout<<conn[i][j]<<" ";
        }
        cout<<endl;
    }
    bfs(conn,p,node);
}

/* Sample Input :
9 10
1 2
1 3
3 4
3 5
1 6
4 6
4 9
9 8
1 7
7 3
*/
