#include<bits/stdc++.h>
using namespace std;


#define mx 100005
#define INF 999999

struct data{
    int u;
    int v;
    int w;
    data(int a,int b,int c){
        u=a;
        v=b;
        w=c;
    }
};

vector<data> adj;
int dis[mx];

int main()
{
    int n,m;
    cin>>n>>m;
    int a,b,w;
    for(int i=0; i<m; i++){
        cin>>a>>b>>w;
        adj.push_back(data(a,b,w));
    }
    int s;
    cout<<"Enter source : ";
    cin>>s;

    for(int i=0; i<=n; i++){
        dis[i] = INF;
    }
    dis[s] = 0;

    for(int i=1; i<n; i++){
        for(int j=0; j<m; j++){
            int u = adj[j].u;
            int v = adj[j].v;
            int w = adj[j].w;
            if(dis[u]!=INF and dis[v] > dis[u] + w){
                dis[v] = dis[u] + w;
            }
        }
    }

    for(int i = 1; i <= n; i++) {
        cout << "Distance of "<< i << " is : " << dis[i] << endl;
    }

    return 0;

}
