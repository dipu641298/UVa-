
//sample input : 5 4 6 3 5 5 7 -1


#include<bits/stdc++.h>
using namespace std;

#define size 100

struct node{
    int data = -1;
    int count =1;
};

void create_bst(struct node ar[], int data, int index)
{
    if(ar[index].data == -1){
        ar[index].data = data;
    }
    else if(ar[index].data != -1){
        if(ar[index].data<data){
            create_bst(ar,data,2*index);
        }
        else if(ar[index].data>data){
            create_bst(ar,data,(2*index)+1);
        }
        else if(ar[index].data == data){
            ar[index].count++;
            create_bst(ar,data,index+1);
        }
    }
}

void inorder(struct node ar[], int index)
{
    if(ar[index].data!=-1){
        inorder(ar,(index*2)+1);
        cout<<ar[index].data<<" ";
        inorder(ar, (2*index));
    }
}

void preorder(struct node ar[], int index)
{
    if(ar[index].data!=-1){
        cout<<ar[index].data<<" ";
        preorder(ar,(index*2)+1);
        preorder(ar, (2*index));
    }
}

void postorder(struct node ar[], int index)
{
    if(ar[index].data!=-1){
        postorder(ar,(index*2)+1);
        postorder(ar, (2*index));
        cout<<ar[index].data<<" ";
    }
}

bool search(struct node ar[],int root, int digit)
{
    if(ar[root].data == -1){
        return false;
    }
    if(ar[root].data == digit){
        cout<<"Found "<<digit<<" in the tree "<<ar[root].count<<" times";
        return true;
    }
    else if(ar[root].data < digit){
        search(ar,(2*root),digit);
    }
    else if(ar[root].data > digit){
        search(ar,(2*root)+1,digit);
    }
}

int main()
{
    struct node ar[size];
    int data,digit;
    bool find;

    while(1){
        //cout<<"Enter a value. Enter -1 to exit : ";
        cin>>data;
        if(data== -1){
            break;
        }
        create_bst(ar,data,1);
    }

    cout<<"\nInorder : ";
    inorder(ar,1);
    cout<<"\nPreorder : ";
    preorder(ar,1);
    cout<<"\nPostorder : ";
    postorder(ar,1);

    cout<<"\nEnter an element to search : ";
    cin>>digit;
    find = search(ar,1,digit);
    if(find){
        cout<<"\nFound element in the tree";
    }
    else if(!find){
        cout<<"\nNot found element in the tree";
    }
}



