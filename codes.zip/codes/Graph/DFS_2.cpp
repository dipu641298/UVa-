#include<bits/stdc++.h>
using namespace std;

struct node{
    string color;
    int startingTime;
    int finishTime;
    string parent;
}n[50];

vector<int> conn [100];
int timee = 0;

void dfs_visit(int u)
{
    n[u].color = "Grey";
    n[u].startingTime = timee++;
    cout<<u<<" ";
    for(int i=0; i<conn[u].size(); i++){
        if(n[conn[u][i]].color=="White"){
            n[conn[u][i]].color = "Grey";
            n[conn[u][i]].parent += u;
            dfs_visit(conn[u][i]);
        }
    }
    n[u].color=="Black";
    n[u].finishTime = timee++;

}


void dfs(int nodeNumber)
{
    for(int i=1; i<=nodeNumber; i++){
        n[i].color = "White";
        n[i].startingTime = 0;
        n[i].finishTime = 0;
        n[i].parent = "";
    }

    for(int i=1; i<=nodeNumber; i++){
        if(n[i].color == "White"){
            dfs_visit(i);
        }
    }
}

int main()
{
    int node,edge,a,b;
    cin>>node>>edge;

    for(int i=0; i<edge; i++){
        cin>>a>>b;
        conn[a].push_back(b);
        conn[b].push_back(a);
    }
    for(int i=1; i<node; i++){
        cout<<i<<"s adjacent is : ";
        for(int j=0; j<conn[i].size(); j++){
            cout<<conn[i][j]<<" ";
        }
        cout<<endl;
    }
    dfs(node);
}

