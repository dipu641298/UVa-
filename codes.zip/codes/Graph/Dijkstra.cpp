#include<bits/stdc++.h>
using namespace std;

#define INF 2e18+1
#define max 1000007

struct data{
    int v;
    long long w;
    data(int a,long long b){
        v=a;
        w=b;
    }

    bool operator<(const data &cmp)const{
        return cmp.w<w;
    }
};

vector< data > adj[max];

int dijkstra(int p, int n)
{
    long long dis[n+1];
    for(int i=0; i<=n; i++){
        dis[i] = INF;
    }
    priority_queue< data > pq;

    pq.push(data(p,0));
    dis[p] = 0;

    while(!pq.empty()){
        int u = pq.top().v;
        pq.pop();

        for(int j=0; j<adj[u].size(); j++){
            int v = adj[u][j].v;
            int weight = adj[u][j].w;

            if(dis[u]+weight <dis[v]){
                dis[v] = dis[u]+weight;
                pq.push(data(v,dis[v]));
            }
        }
    }

    for(int i = 1; i <= n; i++) {
        cout << "Distance of "<< i << " is : " << dis[i] << endl;
    }
}

int main()
{
    int node,edge;
    int a,b,w,p;

    cin>>node>>edge;

    for(int i=0; i<edge; i++){
        cin>>a>>b>>w;
        adj[a].push_back(data(b,w));
        adj[b].push_back(data(a,w));
    }

    cout<<"Enter the source node :";
    cin>>p;

    dijkstra(p,node);
}
