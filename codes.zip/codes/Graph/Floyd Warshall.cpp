#include<bits/stdc++.h>
using namespace std;
#define INF 99999999


int main()
{
    int v,e;
    cin>>v>>e;

    int dis[v+1][v+1];

    for(int i=0; i<=v; i++){
        for(int j=0; j<=v; j++){
            dis[i][j] = INF;
        }
    }
    int a,b,w;
    for(int i=0; i<e; i++){
        cin>>a>>b>>w;
        dis[a][b] = w;
        dis[b][a] = w;
    }

    for(int k = 1; k <=v; k++){
        for(int i = 1; i <=v; i++){
            for(int j = 1; j <=v; j++){
                if(i!=j){
                    dis[i][j] = min( dis[i][j], dis[i][k] + dis[k][j] );
                }
            }
        }
    }
    cout<<endl<<endl;
    for(int i=1; i<=v; i++){
        for(int j=1; j<=v; j++){
            cout<<dis[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}
