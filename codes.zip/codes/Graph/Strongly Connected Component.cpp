#include<bits/stdc++.h>
using namespace std;
#define mx 10007

vector<int> v1[mx];
vector<int> v2[mx];
int visit[mx];
stack<int> st;
vector<int> scc;
bool rev = false;

void dfs( int s)
{
    //cout << s << endl;
    static int t =0 ;
    cout << ++t << endl;
    visit[s] = 1;
    for(int i=0; i<v1[s].size(); i++){
        int x = v1[s][i];
        if(visit[x]==0){
            dfs(x);
        }
    }
    st.push(s);

}

void rev_dfs( int s)
{
    //cout << s << endl;
    scc.push_back(s);
    visit[s] = 1;
    for(int i=0; i<v2[s].size(); i++){
        int x = v2[s][i];
        if(visit[x]==0){
            rev_dfs(x);
        }
    }
    visit[s] = 2;

}

int main()
{
    int v,e;
    cin>>v>>e;
    int a,b;
    for(int i=0; i<e; i++){
        cin>>a>>b;
        v1[a].push_back(b);
        v2[b].push_back(a);
    }

    memset(visit,0,sizeof(visit));

    for(int i=1; i<=v; i++){
        if(visit[i]==0){
            dfs(i);
        }
    }
    int cnt =0 ;
    /*memset(visit,0,sizeof(visit));
    rev = true;
    while(!st.empty()){
        int x = st.top();
        st.pop();
        //cnt = 0;
        if(visit[x]==0){
            cnt++;
            rev_dfs(x);
            cout<<"SCC "<<cnt<< " : ";
            for(int i=0; i<scc.size(); i++){
                cout<<scc[i]<<" ";
            }
            cout<<endl;
            scc.clear();
        }
    }

    cout<<"Numbers of SCC : "<<cnt<<endl;*/

    return 0;
}
