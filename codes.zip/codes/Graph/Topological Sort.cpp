/*Writer : Md. Shafiur Rahman Dipu  */

#include <bits/stdc++.h>
using namespace std;

#define pi 2*acos(0.00)
#define INF 2e18

#define ull unsigned long long
#define ll long long
#define ld long double

#define VI vector<int>
#define QI queue<int>
#define SI stack<int>
#define LI list<int>
#define max 10007

bool visited [105];
VI v[105];
SI st;

void dfs(int a)
{
    visited[a] = true;
    for(int i=0; i<v[a].size(); i++){
        if(!visited[v[a][i]]){
            dfs(v[a][i]);
        }
    }
    st.push(a);
}

bool comp(int a,int b)
{
    return a>b;
}

void func_sort(VI v[], int n)
{
    for(int i=1; i<=n; i++){
        sort(v[i].begin(),v[i].end(),comp);
    }
}


int main()
{
    int n,m;
    cin>>n>>m;
    memset(visited,false,sizeof(visited));

    for(int i=0; i<m; i++){
        int a,b;
        cin>>a>>b;
        v[a].push_back(b);
    }

    func_sort(v,n);

    for(int i=n; i>=1; i--){
        if(!visited[i]){
            dfs(i);
        }
    }

    VI vv;
    while(!st.empty()){
        int x= st.top();
        st.pop();
        vv.push_back(x);
    }

    for(int i=0; i<vv.size(); i++){
        cout<<vv[i]<<" ";
    }
    return 0;
}


