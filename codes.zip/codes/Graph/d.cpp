#include<bits/stdc++.h>
using namespace std;

void bfs(char head, vector<vector<char> > conn,int node)
{
    bool visit [node+1];
    memset(visit,false,sizeof(visit)/sizeof(visit[0]));
    for(int i=0; i<conn[head%26].size(); i++){
        cout<<conn[head][i];
    }

}

int main()
{
    int node,edge;
    char a,b,p;
    cin>>node>>edge;
    vector<char> samp;
    vector<vector<char> > conn(26,samp);
    for(int i=0; i<edge; i++){
        cin>>a>>b;
        conn[a%26].push_back(b);
        conn[b%26].push_back(a);
    }
    cout<<"Enter the node : ";
    cin>>p;
    bfs(p,conn,node);
    return 0;
}

/*
6 9
a b
b a
b c
c d
d d
e d
f e
f f
f a
*/
