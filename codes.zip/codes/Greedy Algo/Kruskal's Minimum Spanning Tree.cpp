#include<bits/stdc++.h>
using namespace std;

int father[105];

struct edge{
    int u,v;
    long long w;
};

bool comp(edge a,edge b)
{
    if(a.w<b.w){
        return true;
    }
    return false;
}

int find(int x)
{
    if(father[x]==x){
        return  x;
    }
    return find(father[x]);
}

void unit(int a,int b)
{
    int fa = find(a);
    int fb = find(b);

    father[fa] = fb;
}

int main()
{
    int n,m,a,b,w;
    vector<edge> ar;

    for(int i=0; i<100; i++){
        father[i] = i;
    }

    cin>>n>>m;
    edge e;
    for(int i=0; i<m; i++){
        cin>>e.u>>e.v>>e.w;
        ar.push_back(e);

    }
    cout<<endl;

    int mst_w = 0;
    int mst_edges = 0;
    int mst_ni = 0;

    sort(ar.begin(),ar.end(),comp);

    while(mst_edges<n-1 || mst_ni<m){
        a = ar[mst_ni].u;
        b = ar[mst_ni].v;
        w = ar[mst_ni].w;

        if(find(a)!=find(b)){
            unit(a,b);

            mst_w+=w;
            cout<<a<<" "<<b<<endl;

            mst_edges++;
        }

        mst_ni++;
    }

    cout<<"Weight of minimum spanning tree : "<<mst_w<<endl;
    cout<<"Number of edges in minimum spanning tree : "<<mst_edges<<endl;
    //cout<<mst_ni<<endl;
    return 0;
}
/*
9 10
1 9 5
1 2 5
2 3 5
3 4 5
4 5 5
4 6 5
5 7 5
7 6 5
7 8 5
8 6 5
*/
