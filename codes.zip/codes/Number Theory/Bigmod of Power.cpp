/*Writer : Md. Shafiur Rahman Dipu  */

#include <bits/stdc++.h>
using namespace std;

#define pi 2*acos(0.00)
#define INF 2e18

#define ull unsigned long long
#define ll long long
#define ld long double

#define vi vector<int>
#define qi queue<int>
#define si stack<int>
#define li list<int>
#define pb push_back
#define mx 100000007

#define rep(a,b) for(int i=a; i<b; i++)

void print2(vi v){for(int i=0; i<v.size(); i++){cout<<v[i]<<" ";}cout<<endl;}
void print1(int ar[],int n){for(int i=0; i<n; i++){cout<<ar[i]<<" ";}cout<<endl;}

ll bigmod(int number, int power, int mod)
{
    if(power==0){
        return 1;
    }
    else if(power%2==0){
        ll ret = bigmod(number,power/2,mod);
        return ((ret%mod)*(ret%mod))%mod;
    }
    else return ((number%mod)*(bigmod(number,power-1,mod)%mod))%mod;
}


int main()
{
    #ifdef dipu
    //freopen("inp.txt","r",stdin);
    #endif

    return 0;
}

