#include<bits/stdc++.h>
using namespace std;

const int maxx = (int)1e8;

int check[maxx/32+7];
vector<int> prime;

bool getBit(int n, int pos)
{
    return n & (1<<pos);
}

int setBit(int n, int pos)
{
    return n = n | (1<<pos);
}


void bitwise_sieve()
{
    int m = (int)sqrt(maxx);
    for(int i=3; i<=m; i+=2){
        if(!getBit(check[i>>5],i&31)){
            for(int j=i*i; j<=maxx; j+=(i<<1)){
                check[j>>5] = setBit(check[j>>5],j&31);
            }
        }
    }
    cout<<2<<endl;
    int cnt = 0;
    for(int i=3; i<=maxx; i+=2){
        if(!getBit(check[i>>5],i&31)){
		     cnt++;
             if(cnt==100){
                cnt=0;
                printf("%d\n",i);
             }
		 }
    }
}

int main()
{
    bitwise_sieve();

    return 0;

}
