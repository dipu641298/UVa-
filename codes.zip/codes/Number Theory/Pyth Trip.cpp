#include<bits/stdc++.h>
using namespace std;

int main()
{
    int range = 1000;
    int ar[1001];
    for(int i=0; i<=1000; i++){
        ar[i] = 0;
    }

    for(int i=1; i<=1000; i++){
        for(int j=1; j<=1000; j++){
            for(int k=1; k<=1000; k++){
                if(k*k + j*j == i*i){
                    if(ar[k]!=1 && ar[j]!=1){
                        printf("%d %d %d\n",k,j,i);
                        ar[k]=1;
                        ar[j]=1;
                    }
                }
            }
        }
    }

    return 0;
}
