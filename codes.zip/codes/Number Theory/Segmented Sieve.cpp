/*Writer : Md. Shafiur Rahman Dipu  */

#include <bits/stdc++.h>
using namespace std;

#define pi acos(-1)
#define INF 2e18

#define ull unsigned long long
#define ll long long
#define ld long double

#define VI vector<int>
#define QI queue<int>
#define SI stack<int>
#define LI list<int>
#define max 10007

int cnt=0;

bool ch[10000000000] = {false};

int sieve(int limit,vector<int> prime,ull n)
{
    bool mark[limit+1];
    memset(mark,true,sizeof(mark));
    for (int p=2; p*p<limit; p++){
        if (mark[p] == true){
            for (int i=p*2; i<limit; i+=p)
                mark[i] = false;
        }
    }

    for (int p=2; p<limit; p++){
        if (mark[p] == true)
        {
            prime.push_back(p);
            ch[p] = true;

        }
    }

    return 1;
}

int segSieve(ull n)
{
    int limit = floor(sqrt(n))+1;
    vector<int> prime;
    int w = sieve(limit,prime,n);
    if(w==0){
        return 0;
    }

    int low = limit;
    int high = 2*limit;

    while(low<n){
        bool mark[limit+1];
        memset(mark,true,sizeof(mark));

        for(int i=0; i<prime.size(); i++){
            int loLim = floor(low/prime[i]) * prime[i];
            if(loLim<low){
                loLim+=prime[i];
            }

            for(int j=loLim; j<high; j+=prime[i]){
                mark[j-low] = false;
            }
        }

        for(int i = low; i<high; i++){
            if(mark[i-low]==true){
                ch[i] = true;
            }
        }

        low  = low + limit;
        high = high + limit;
        if (high >= n){
            high = n;
        }
    }

    return 1;
}



int main()
{
    int tc;
    cin>>tc;
    segSieve(100000000000);
    while(tc){
        ull n;
        cin>>n;
        if(ch[n]==true){
            cout<<n<<" is a prime"<<endl;
        }
        else if(ch[n]==false){
            cout<<n<<" is not a prime"<<endl;
        }
        tc--;
    }

    return 0;
}



