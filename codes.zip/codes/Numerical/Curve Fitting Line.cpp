#include<bits/stdc++.h>
using namespace std;

#define n 5
double x[] = {1,2,3,4,5};
double y[] = {3,4,5,6,8};

double sum_x ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += x[i];
  }
  return sum;
}

double sum_y ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += y[i];
  }
  return sum;
}

double sum_xy ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += x[i]*y[i];
  }
  return sum;
}

double sum_x2 ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += pow(x[i],2);
  }
  return sum;
}



int main()
{
  double sumx = sum_x();
  double sumy = sum_y();
  double sumxy = sum_xy();
  double sumxSumy = sumx*sumy;
  double sumx2 = sum_x2();

  double b = (n*sumxy - sumxSumy)/(n*sumx2 - pow(sumx,2));
  double a = sumy/n - b*(sumx/n);
  printf("The equation is y = %.2lf + %.2lfx",a,b);

  return 0;
}

