#include<bits/stdc++.h>
using namespace std;

int order,n,m,p;
double x[100],y[100],sumx[100],sumxy[100],c[100][100],b[100],a[100];
double d,sum;


void ge()
{
    sum = 0;
    for(int j=1; j<=m; j++){
        for(int i=1; i<=m; i++){
            if(i>j){
                d = c[i][j]/c[j][j];
                for(int k=j; k<=m; k++){
                    c[i][k]=c[i][k]-d*c[j][k];
                }
                b[i] = b[i] - d*b[j];
            }
        }
    }
    a[m] = b[m]/c[m][m];

    for(int i=m-1; i>=1; i--)    {
        sum=0;
        for(int j=i+1; j<=m; j++)        {
            sum=sum+c[i][j]*a[j];
        }
        a[i]=(b[i]-sum)/c[i][i];
    }

    cout<<"Solution : ";
    for(int i=1; i<=m; i++){
        printf("\na%d = %lf\t",i,a[i]);
    }
}


int main()
{
    cout<<"Enter n and order : ";
    cin>>n>>order;

    if(n<=order){
        cout<<"Regression is not possible"<<endl;
        return 0;
    }
    else{
        for(int i=1; i<=n; i++){
            cin>>x[i]>>y[i];
        }

        m = order +1;
        p = 2*order+1;

        for(int i=0; i<p; i++){
            sumx[i] = 0;
            for(int j=1; j<=n; j++){
                sumx[i] += pow(x[j],i);
            }
        }
        for(int i=0; i<m; i++){
            sumxy[i] =  0;
            for(int j=1; j<=n; j++){
                sumxy[i] += pow(x[j],i)*y[j];
            }
        }

        for(int i = 1; i<=m; i++){
            for(int j=1; j<=m; j++){
                c[i][j] = sumx[i+j-2];
            }
        }

        for(int i=1; i<=m; i++){
            b[i] = sumxy[i-1];
        }


        cout<<"\nThe Normal(Augmented Matrix) is as follows:\n"<<endl;
        for (int i=1; i<=m; i++){
            for (int j=1; j<=m; j++){
                cout<<c[i][j]<<" ";
            }
            cout<<" = "<< b[i]<<endl;
        }

        ge();
    }


    return 0;
}
