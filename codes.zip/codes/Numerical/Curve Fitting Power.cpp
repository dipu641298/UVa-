#include<bits/stdc++.h>
#define n 5
using namespace std;
double x[] = {1,2,3,4,5};
double y[] = {.5,2,4.5,8,12.5};


void makeln()
{
  for(int i=0;i<n;i++)
  {
    x[i] = log(x[i]);
    y[i] = log(y[i]);
  }

}

double sum_x ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += x[i];
  }
  return sum;
}

double sum_y ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += y[i];
  }
  return sum;
}

double sum_xy ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += x[i]*y[i];
  }
  return sum;
}

double sum_x2 ()
{
  double sum =0;
  for(int i=0;i<n;i++)
  {
    sum += pow(x[i],2);
  }
  return sum;
}



int main()
{

  makeln();
  double sumx = sum_x(); // printf("%lf\n",sumx);
  double sumy = sum_y();// printf("%lf\n",sumy);
  double sumxy = sum_xy(); // printf("%lf\n",sumxy);
  double sumxSumy = sumx*sumy; // printf("%lf\n",sumxSumy);
  double sumx2 = sum_x2(); // printf("%lf\n",sumx2);

  double b = (n*sumxy - sumxSumy)/(n*sumx2 - pow(sumx,2));
  double a = sumy/n - b*(sumx/n);
  a = exp(a);
  printf("The equation is y = %.2lfx^%.2lf",a,b);

  return 0;
}

