#include<bits/stdc++.h>
using namespace std;
double f(double x)
{
    return ((x*x)-(4*x)-10);
}

int main()
{
    double x1, x2, e=0.001, x0, fx1, fx2, fx0, stop=0, root;
    cout<<"Input initial values x1 and x2: ";
    cin>>x1>>x2;
    fx1=f(x1);
    fx2=f(x2);
    if((fx1*fx2>0)){
        cout<<"\nx1 and x2 do not bracket any root";
    }
    else{
        while(stop==0){
            fx1 = f(x1);
            fx2 = f(x2);
            x0= x1-((fx1*(x2-x1))/(fx2-fx1));
            fx0=f(x0);

            if(fx1*fx0<0){
                x2=x0;
            }
            else{
                x1=x0;
            }

            root= fabs((x2-x1)/x2);
            cout<<root<<endl;
            if(root<e){
                root = (x1+x2)/2;
                stop=1;
            }
        }
        if(stop==1){
            cout<<"\nThe root is:"<<root;
        }
    }
}


