#include<bits/stdc++.h>
using namespace std;

float a[10][10];

void normalize(int x, int n)
{
    float div = a[x][x];
    for(int i=1; i<=n+1; i++){
        a[x][i] /= div;
    }

}


int main()
{
    cout<<"Enter the order of matrix : ";
    int n;
    cin>>n;
    cout<<"Input elements row wise : "<<endl;

    for(int i=1; i<=n; i++){
        for(int j=1; j<=n+1; j++){
            //printf("A[%d][%d]: ", i, j);
            cin>>a[i][j];
        }
    }

    for(int i=1; i<=n; i++){
        normalize(i,n);
        for(int j=1; j<=n; j++){
            if(i!=j){
                float mul = a[j][i];
                for(int k=1; k<=n+1; k++){
                    a[j][k] -= mul*a[i][k];
                }
            }
        }
    }

    for(int i=1; i<=n; i++){
        cout<<"x"<<i<<" : "<<a[i][n+1]<<endl;
    }


    return 0;
}
