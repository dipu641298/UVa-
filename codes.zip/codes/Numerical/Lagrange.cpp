#include<bits/stdc++.h>
using namespace std;


int main()
{
    double x[10],y[10],a;
    int n;
    cout<<"Enter the number of observation : ";
    cin>>n;
    cout<<"Enter the values of x : ";
    for(int i=0; i<n; i++){
        cin>>x[i];
    }
    cout<<"Enter the values of corresponding y : ";
    for(int i=0; i<n; i++){
        cin>>y[i];
    }

    cout<<"The created table is as followed : "<<endl;
    for(int i=0; i<n; i++){
        cout<<x[i]<<"   "<<y[i]<<endl;
    }

    cout<<"Enter the value of x to find y : ";
    cin>>a;

    double s,t,k = 0.00;
    for(int i=0; i<n; i++){
        s = 1.00;
        t = 1.00;
        for(int j=0; j<n; j++){
            if(i!=j){
                s *= (a-x[j]);
                t *= (x[i]-x[j]);
            }
        }
        k += (s/t)*y[i];
    }

    printf("For x = %lf y is = %lf",a,k);

    return 0;
}
