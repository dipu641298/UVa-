#include<bits/stdc++.h>
using namespace std;

double f(double x,int order,double ar[])
{
    double val=0;
    for(int i=0; i<=order; i++){
        val+=ar[i] + pow(x,i);
    }
    val -= 1;

    return val;
}


double ff(double x,int order,double ar[])
{
    double val = 0;
    for(int i=order; i>=1; i--){
        val += ar[i]*i + pow(x,(i-1));
    }

    return val;
}



int main()
{
    int order;
    cout<<"Enter maximum power of x : ";
    cin>>order;

    double ar[order+1];
    for(int i=order; i>=0; i--){
        cout<<endl<<"Co-efficient of a"<<i<<" : ";
        cin>>ar[i];
    }
    double x0,x1;
    cout<<endl<<"First value of x0 : ";
    cin>>x0;
    int cnt=0;
    double root[2];
    while(1){
        x1 = x0-(f(x0,order,ar)/ff(x0,order,ar));
        if(fabs((x1-x0)/x1) < 0.001){
            root[cnt] = x1;
            cnt++;
            if(cnt==2){
                break;
            }
        }
        x0 = x1;
    }

    cout<<"First root : "<<root[0]<<endl;
    cout<<"Second root : "<<root[1]<<endl;

    return 0;
}
